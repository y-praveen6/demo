import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'jhi-docs',
  templateUrl: './docs.component.html',
  styleUrl: './docs.component.scss',
})
export default class DocsComponent {}
