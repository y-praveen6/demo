/**
 * Application security utilities.
 */
package com.javaocean.demo.security;
