/**
 * Domain objects.
 */
package com.javaocean.demo.domain;
