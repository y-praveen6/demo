/**
 * Logging aspect.
 */
package com.javaocean.demo.aop.logging;
