/**
 * Application configuration.
 */
package com.javaocean.demo.config;
