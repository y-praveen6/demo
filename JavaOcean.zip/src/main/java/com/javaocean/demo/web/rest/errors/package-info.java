/**
 * Rest layer error handling.
 */
package com.javaocean.demo.web.rest.errors;
