/**
 * Rest layer.
 */
package com.javaocean.demo.web.rest;
